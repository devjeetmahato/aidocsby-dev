
export type DocSectionType = 'header' | 'subheader' | 'paragraph' | 'list' | 'diagram' | 'quote' | 'highlight';

export interface DocSection {
  type: DocSectionType;
  content?: string;
  items?: string[]; // For list
  code?: string;   // For diagram (Mermaid)
  explanation?: string; // For diagram
}

export interface GeneratedDocument {
  title: string;
  subtitle?: string;
  author?: string;
  sections: DocSection[];
  readabilityScore: number;
  wordCount: number;
  toneSummary: string;
}

export type DocTheme = 'academic' | 'corporate' | 'creative' | 'exam';

export interface FileInput {
  name: string;
  type: string;
  data: string; // Base64
}
