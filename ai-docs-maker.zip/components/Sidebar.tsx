
import React from 'react';
import { FileInput as FileInputType, DocTheme } from '../types';
import { THEMES } from '../constants';

interface SidebarProps {
  rawText: string;
  setRawText: (text: string) => void;
  files: FileInputType[];
  onFileUpload: (files: FileList | null) => void;
  onRemoveFile: (index: number) => void;
  theme: DocTheme;
  setTheme: (theme: DocTheme) => void;
  onGenerate: () => void;
  isGenerating: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({
  rawText,
  setRawText,
  files,
  onFileUpload,
  onRemoveFile,
  theme,
  setTheme,
  onGenerate,
  isGenerating
}) => {
  return (
    <aside className="w-full lg:w-96 bg-white border-r border-slate-200 h-screen overflow-y-auto p-6 flex flex-col gap-8 no-print">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-xl font-bold">🧠</div>
        <h1 className="text-xl font-bold tracking-tight text-slate-800">AI Docs Maker</h1>
      </div>

      <section className="space-y-4">
        <label className="block text-sm font-semibold text-slate-700">Rough Input / Notes</label>
        <textarea
          className="w-full h-40 p-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all resize-none text-sm"
          placeholder="Paste your rough text, bullets, or messy drafts here..."
          value={rawText}
          onChange={(e) => setRawText(e.target.value)}
        />
      </section>

      <section className="space-y-4">
        <label className="block text-sm font-semibold text-slate-700">Assets (Images, PDFs)</label>
        <div className="border-2 border-dashed border-slate-200 rounded-lg p-4 text-center hover:border-indigo-400 transition-colors group">
          <input
            type="file"
            id="file-upload"
            multiple
            accept="image/*,.pdf,.txt,.docx"
            className="hidden"
            onChange={(e) => onFileUpload(e.target.files)}
          />
          <label htmlFor="file-upload" className="cursor-pointer block">
            <div className="text-slate-400 group-hover:text-indigo-500 mb-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
            </div>
            <p className="text-xs text-slate-500">Upload handwritten notes, diagrams, or drafts</p>
          </label>
        </div>
        
        {files.length > 0 && (
          <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
            {files.map((file, idx) => (
              <div key={idx} className="flex items-center justify-between bg-slate-50 p-2 rounded-md border border-slate-100 group">
                <div className="flex items-center gap-2 truncate">
                  <span className="text-lg">📄</span>
                  <span className="text-xs font-medium text-slate-600 truncate">{file.name}</span>
                </div>
                <button 
                  onClick={() => onRemoveFile(idx)}
                  className="text-slate-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-4">
        <label className="block text-sm font-semibold text-slate-700">Select Theme</label>
        <div className="grid grid-cols-2 gap-3">
          {(Object.entries(THEMES) as [DocTheme, any][]).map(([key, value]) => (
            <button
              key={key}
              onClick={() => setTheme(key)}
              className={`p-3 rounded-xl border-2 text-left transition-all ${
                theme === key 
                ? 'border-indigo-600 bg-indigo-50 text-indigo-700' 
                : 'border-slate-100 bg-white hover:border-slate-200 text-slate-600'
              }`}
            >
              <div className="text-xl mb-1">{value.icon}</div>
              <div className="text-xs font-bold">{value.name}</div>
            </button>
          ))}
        </div>
      </section>

      <button
        onClick={onGenerate}
        disabled={isGenerating || (rawText.length === 0 && files.length === 0)}
        className={`w-full py-4 rounded-xl font-bold shadow-lg shadow-indigo-200 transition-all transform hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 ${
          isGenerating 
          ? 'bg-slate-300 cursor-not-allowed text-slate-500' 
          : 'bg-indigo-600 text-white hover:bg-indigo-700'
        }`}
      >
        {isGenerating ? (
          <>
            <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Transforming...
          </>
        ) : (
          <>✨ Magic Transform</>
        )}
      </button>
      
      <div className="mt-auto text-[10px] text-slate-400 text-center">
        Powered by Gemini 3 & AI Docs Logic
      </div>
    </aside>
  );
};

export default Sidebar;
