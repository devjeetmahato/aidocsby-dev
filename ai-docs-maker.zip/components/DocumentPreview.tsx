
import React, { useEffect, useRef } from 'react';
import { GeneratedDocument, DocTheme } from '../types';
import { THEMES } from '../constants';

interface DocumentPreviewProps {
  document: GeneratedDocument | null;
  theme: DocTheme;
  isGenerating: boolean;
}

const DocumentPreview: React.FC<DocumentPreviewProps> = ({ document, theme, isGenerating }) => {
  const mermaidRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (document && (window as any).mermaid) {
      (window as any).mermaid.initialize({ startOnLoad: true, theme: 'default' });
      (window as any).mermaid.contentLoaded();
    }
  }, [document]);

  if (isGenerating) {
    return (
      <div className="flex-1 h-screen flex flex-col items-center justify-center p-12 bg-slate-50 overflow-hidden">
        <div className="w-full max-w-2xl space-y-8 animate-pulse">
          <div className="h-12 bg-slate-200 rounded-lg w-3/4"></div>
          <div className="space-y-4">
            <div className="h-4 bg-slate-200 rounded w-full"></div>
            <div className="h-4 bg-slate-200 rounded w-full"></div>
            <div className="h-4 bg-slate-200 rounded w-5/6"></div>
          </div>
          <div className="h-48 bg-slate-200 rounded-xl w-full"></div>
          <div className="space-y-4">
            <div className="h-4 bg-slate-200 rounded w-full"></div>
            <div className="h-4 bg-slate-200 rounded w-1/2"></div>
          </div>
        </div>
        <p className="mt-8 text-slate-500 font-medium animate-bounce">Our AI is reading your diagrams and notes...</p>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="flex-1 h-screen flex flex-col items-center justify-center p-12 text-center">
        <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center text-4xl mb-6">📄</div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Ready for Transformation</h2>
        <p className="text-slate-500 max-w-sm">Upload your rough notes or images on the left, and watch them become a professional document instantly.</p>
      </div>
    );
  }

  const themeConfig = THEMES[theme];

  return (
    <div className="flex-1 h-screen overflow-y-auto bg-slate-200 p-4 md:p-8 lg:p-12 scroll-smooth" id="pdf-content">
      <div className={`mx-auto max-w-[210mm] min-h-[297mm] bg-white shadow-2xl p-12 md:p-20 relative ${themeConfig.class}`}>
        {/* Header Metadata (Meta information) */}
        <div className="mb-12 border-b border-slate-100 pb-8 no-print">
          <div className="flex flex-wrap gap-4 text-xs font-medium text-slate-400">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              Readability: {document.readabilityScore}/100
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              Words: {document.wordCount}
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-purple-500"></span>
              Tone: {document.toneSummary}
            </div>
          </div>
        </div>

        {/* Title Section */}
        <header className="mb-16">
          <h1 className="text-5xl font-extrabold text-slate-900 leading-tight mb-4 tracking-tight">
            {document.title}
          </h1>
          {document.subtitle && (
            <p className="text-2xl text-slate-500 font-light italic">{document.subtitle}</p>
          )}
          {document.author && (
            <div className="mt-8 text-slate-600 font-semibold border-t-2 border-slate-900 pt-4 inline-block">
              {document.author}
            </div>
          )}
        </header>

        {/* Content Sections */}
        <main className="space-y-12">
          {document.sections.map((section, idx) => {
            switch (section.type) {
              case 'header':
                return (
                  <h2 key={idx} className="text-3xl font-bold text-slate-800 border-b-4 border-indigo-100 pb-2 inline-block">
                    {section.content}
                  </h2>
                );
              case 'subheader':
                return (
                  <h3 key={idx} className="text-xl font-bold text-slate-700 tracking-wide uppercase mt-8">
                    {section.content}
                  </h3>
                );
              case 'paragraph':
                return (
                  <p key={idx} className="text-lg leading-relaxed text-slate-700">
                    {section.content}
                  </p>
                );
              case 'list':
                return (
                  <ul key={idx} className="space-y-3 list-disc pl-6 text-lg text-slate-700">
                    {section.items?.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                );
              case 'diagram':
                return (
                  <div key={idx} className="my-10 bg-slate-50 rounded-2xl p-8 border border-slate-100">
                    <div className="mermaid flex justify-center overflow-x-auto py-4" ref={mermaidRef}>
                      {section.code}
                    </div>
                    {section.explanation && (
                      <div className="mt-6 pt-6 border-t border-slate-200">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-2">Analysis</span>
                        <p className="text-sm italic text-slate-600 leading-relaxed">{section.explanation}</p>
                      </div>
                    )}
                  </div>
                );
              case 'quote':
                return (
                  <blockquote key={idx} className="border-l-8 border-indigo-600 pl-8 py-4 my-8 bg-indigo-50/50 rounded-r-xl">
                    <p className="text-2xl font-serif italic text-indigo-900 leading-snug">
                      "{section.content}"
                    </p>
                  </blockquote>
                );
              case 'highlight':
                return (
                  <div key={idx} className="bg-yellow-50 border-2 border-yellow-100 p-6 rounded-2xl my-8 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-2 text-yellow-200 group-hover:text-yellow-300 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
                      </svg>
                    </div>
                    <div className="relative z-10">
                      <h4 className="font-bold text-yellow-800 uppercase text-xs tracking-widest mb-2">Key takeaway</h4>
                      <p className="text-lg text-yellow-900 leading-relaxed">{section.content}</p>
                    </div>
                  </div>
                );
              default:
                return null;
            }
          })}
        </main>

        {/* Footer info (Print only) */}
        <footer className="mt-24 border-t border-slate-100 pt-8 text-[10px] text-slate-300 print-only flex justify-between">
          <span>Generated by AI Docs Maker</span>
          <span>&copy; {new Date().getFullYear()}</span>
        </footer>
      </div>
      
      {/* Floating Action Menu for Preview Only */}
      <div className="fixed bottom-8 right-8 flex flex-col gap-4 no-print">
        <button 
          onClick={() => window.print()}
          className="bg-slate-900 text-white p-4 rounded-full shadow-2xl hover:bg-slate-800 transition-all flex items-center justify-center group"
          title="Download PDF"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 transition-all duration-300 font-bold text-sm">Download PDF</span>
        </button>
      </div>
    </div>
  );
};

export default DocumentPreview;
