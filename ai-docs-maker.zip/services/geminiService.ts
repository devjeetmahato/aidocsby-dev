
import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedDocument, FileInput } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const DOC_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    subtitle: { type: Type.STRING },
    author: { type: Type.STRING },
    sections: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING, description: "One of: header, subheader, paragraph, list, diagram, quote, highlight" },
          content: { type: Type.STRING },
          items: { type: Type.ARRAY, items: { type: Type.STRING } },
          code: { type: Type.STRING, description: "Mermaid.js syntax if type is diagram" },
          explanation: { type: Type.STRING, description: "Context or caption for diagrams" }
        },
        required: ["type"]
      }
    },
    readabilityScore: { type: Type.NUMBER },
    wordCount: { type: Type.NUMBER },
    toneSummary: { type: Type.STRING }
  },
  required: ["title", "sections", "readabilityScore", "wordCount", "toneSummary"]
};

export async function processDocument(
  rawText: string,
  files: FileInput[],
  tone: string
): Promise<GeneratedDocument> {
  const model = "gemini-3-flash-preview";
  
  const fileParts = files.map(f => ({
    inlineData: {
      data: f.data.split(',')[1], // Remove mime prefix
      mimeType: f.type
    }
  }));

  const systemInstruction = `
    You are an expert document architect and technical writer. 
    Your task is to take messy, rough inputs (notes, images, diagrams, text) and transform them into a clean, human-like, visually attractive document.
    
    GUIDELINES:
    1. Rearrange content logically with a clear flow.
    2. Use humanized, active-voice language. Avoid robotic "AI-isms".
    3. Detect diagrams or processes from images and translate them into Mermaid.js code for visualization.
    4. Structure with headers, subheaders, lists, and highlight boxes.
    5. Tone requested: ${tone}.
    6. If a diagram is complex, provide a clear textual explanation after the visualization.
  `;

  const prompt = `
    Please process the following rough inputs into a structured document.
    
    TEXT INPUT:
    ${rawText}
    
    FILES PROVIDED: ${files.length} (attached as multimodal input)
    
    Target Tone: ${tone}
  `;

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        ...fileParts,
        { text: prompt }
      ]
    },
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: DOC_SCHEMA
    }
  });

  const jsonStr = response.text;
  if (!jsonStr) throw new Error("No response from AI");
  
  return JSON.parse(jsonStr) as GeneratedDocument;
}
