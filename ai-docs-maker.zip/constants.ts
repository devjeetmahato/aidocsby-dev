
import { DocTheme } from './types';

export const THEMES: Record<DocTheme, { name: string; class: string; icon: string }> = {
  academic: {
    name: 'Academic',
    class: 'font-serif prose-slate',
    icon: '🎓'
  },
  corporate: {
    name: 'Corporate',
    class: 'font-sans prose-blue font-medium',
    icon: '💼'
  },
  creative: {
    name: 'Creative',
    class: 'font-poppins prose-indigo text-indigo-900',
    icon: '🎨'
  },
  exam: {
    name: 'Exam-Ready',
    class: 'font-mono prose-emerald border-l-4 border-emerald-500 pl-4',
    icon: '📚'
  }
};
